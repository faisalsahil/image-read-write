class StaticPagesController < ApplicationController
  def home
  end

  def help
  end

  def about
  end

  def contact
  end

  def upload
    require 'RMagick'
  	image = params[:image]
  	# png = Base64.decode64(data_url['data:image/png;base64,'.length .. -1])
  	png = Base64.decode64(image)
  	
  	File.open('shipping_label.png', 'wb') do|f|
  	f.write(Base64.decode64(image))
	end

  f = File.open('tux.png');
  puts "===================="
  puts blob = f.read
  puts "======================"
	ilist = Magick::ImageList.new
  ilist.from_blob(blob)
  f = File.open('shipping_label.png');
  blob = f.read
  ilist.from_blob(blob)

  ilist.flatten_images.write "flatten_images.png"

	# File.open('test.png', 'wb') { |f| f.write(png) }
  	render json: "hello"
  end
end
